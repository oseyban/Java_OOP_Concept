package oopConcepts.polimorfizm.Sample2;

public class User {

    String name;
    Integer age;
    String phoneNumber;
}

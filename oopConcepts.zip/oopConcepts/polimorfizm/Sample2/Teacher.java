package oopConcepts.polimorfizm.Sample2;

public class Teacher extends User{
}

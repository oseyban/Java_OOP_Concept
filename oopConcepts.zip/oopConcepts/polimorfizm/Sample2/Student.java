package oopConcepts.polimorfizm.Sample2;

public class Student extends User{
}

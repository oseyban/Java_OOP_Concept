package oopConcepts.polimorfizm.Shape;

public interface Shape {
    void draw();
}

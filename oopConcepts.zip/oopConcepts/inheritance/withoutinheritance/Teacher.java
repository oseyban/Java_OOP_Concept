package oopConcepts.inheritance.withoutinheritance;

public class Teacher {

    private String name;
    private String username;
    private String surname;
    private String password;
    private String phoneNumber;
    private String lesson; // hangi derse girecek

    public void displayLesson(){
        System.out.println("Ogretmenin dersleri ....");
    }

}
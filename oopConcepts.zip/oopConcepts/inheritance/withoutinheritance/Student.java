package oopConcepts.inheritance.withoutinheritance;

public class Student {

    private String name;
    private String surname;
    private String username;
    private String password;
    private String phoneNumber;
    private String studentNumber;

    public void displayLessons(){
        System.out.println("ogrencinin tum dersleri ....");
    }
}
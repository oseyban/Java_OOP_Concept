package oopConcepts.inheritance.withoutinheritance.withInheritance;

public class Student extends User {

    public String studentNumber;
}
package oopConcepts.inheritance.withoutinheritance.withInheritance;

public class User {

    protected String name ;
    protected String surname ;
    private String username ;
    private String password ;
    protected String phoneNumber ;

    public void displayLessons(){
        System.out.println( name + " kisisinin tum dersleri ....");
    }
}
package oopConcepts.oop.abstraction;

public class Calculator {

    // Bu metod 2 sayiyi topluyor
    public int add(int num1, int num2){
        return num1+num2;
    }
}
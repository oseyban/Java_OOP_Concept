package oopConcepts.constructor;

public class Book {
    public String name;
    public String author;
    public String publisher;
    public int pageNumber;
    public double price;

    public Book(){}

    public Book(String name, String author, String publisher, int pageNumber, double price) {
        this.name = name;
        this.author = author;
        this.publisher = publisher;
        this.pageNumber = pageNumber;
        this.price = price;
    }

    public static void main(String[] args) {
        Book book1 = new Book();
        book1.name="Şeker portakalı";
        book1.publisher="Can Yayınları";
        book1.pageNumber=180;
        book1.price=100.0;

        Book book2 = new Book("A","B","C",100,120.0);


    }
}
